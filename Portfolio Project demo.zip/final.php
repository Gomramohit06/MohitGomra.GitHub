<!DOCTYPE html>
<html>
<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>P1N Final Project</title>
	 <link rel="stylesheet" href="style.css">
</head>
<body>


<?php
$con=mysqli_connect("localhost","root","","p1n");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}  
    
    ?>


<div class="header">
	<div class="icon">
		<img src="01.png"/>
		<img src="02.png"/>
		<img src="03.png"/>
		<img src="04.png"/>
		<img src="05.png"/>
	</div>
	<h6>We Ship Worldwide!</h6>
	<div class="icon1">
		<img src="06.png" width="24px" height="24px"/>
		<img src="07.webp" width="24px" height="24px"/>
		<img src="08.png" width="24px" height="24px"/>
	</div>
</div>
</br>
<div class="logo">
   <img src="logo2.webp"/>
</div>
<div class="menu"> 
	       <a href="#">TCStyling.com</a>
		   <a href="#">NEW|NOUVEAUTES</a>
		   <a href="#">SALE</a>
	       <a href="#">CATEGORIES˅</a>
	       <a href="#">COLLECTION˅</a>
		   <a href="#">DESIGNERS˅</a>
	       
    </div>
</br>
</br>
</br>
<div class="banner">
   
   
   
   <?php 
    
    $sql = "SELECT image FROM fetchimage Where img_typ = 1";
$result = mysqli_query($con,$sql);

$row = mysqli_fetch_array($result, MYSQLI_ASSOC); 
    $banner = $row["image"];
    ?>
   
    <img src="<?php echo $banner; ?>" width=100%/>
</div>
</br>
<h1>NEW ARRIVALS|NOUVEAUTES</h1>
</br>
<div class="container">
     <?php 
    
   $sql = "SELECT * FROM fetchimage Where img_typ = 2";

if ($result = $con -> query($sql)) { 
    
    
    $count = 0;
    
  while ($fieldinfo = $result -> fetch_assoc()) {
      if($count < 4){
     $pimage = $fieldinfo['image'];
      
 ?>
    
    
    
    <img src="<?php echo   $pimage; ?>" width=252px height=252px/> 
	
	
	<?php 
         
          
      } $count++;
      
       }
  $result -> free_result();
}
    ?>
	
	
</div>
<div id="para1">ACCESSOIRES&SOINS   ACCESSOIRES&SOINS  ACCESSOIRES&SOINS  ACCESSOIRES&SOINS</div>
<div id="para2">Beanie-authentique-Grispale  Beanie-authentique-Grisfonce  Beanie-authentique-Olive  Beanie-authentique-Orange</div>
<div id="para3">$495.00  $995.00  $1295.00  $525.00</div>
<h2>NEVER OUT OF STOCK</h2>
<div class="container">
 <?php 
    
   $sql = "SELECT * FROM fetchimage Where img_typ = 2";

if ($result = $con -> query($sql)) { 
    
    
    $counts = 0;
    
  while ($fieldinfo = $result -> fetch_assoc()) {
      if($counts >= 4){
     $pimagess = $fieldinfo['image'];
      
 ?>
    
    
    
    <img src="<?php echo   $pimagess; ?>" width=252px height=252px/> 
	
	
	<?php 
         
          
      }
       $counts++;
       }
  $result -> free_result();
}
    ?>
</div>
<div id="para1">ACCESSOIRES&SOINS   ACCESSOIRES&SOINS  ACCESSOIRES&SOINS  ACCESSOIRES&SOINS </div>
<div id="para2">Beanie-authentique-Grispale  Beanie-authentique-Grisfonce  Beanie-authentique-Olive  Beanie-authentique-Orange</div>
<div id="para3">$495.00  $995.00  $1295.00  $525.00</div>
<div class="button-image">
   
   
   
   <?php 
    
   $sql = "SELECT * FROM fetchimage Where img_typ = 3";

if ($result = $con -> query($sql)) { 
    
    
    
    
  while ($fieldinfo = $result -> fetch_assoc()) {
      
     $pimagess = $fieldinfo['image'];
      
 ?>
    
    
    
    <img src="<?php echo   $pimagess; ?>" width=350px height=350px/> 
	
	
	<?php 
         
          
      
       }
  $result -> free_result();
}
    ?>
    
</div>
</br>
</br>
<h2>COLLECTION</h2>
</br>
<div class="image-container">
   
   
   
   <?php 
    
   $sql = "SELECT * FROM fetchimage Where img_typ = 4";

if ($result = $con -> query($sql)) { 
    
    
    
    
  while ($fieldinfo = $result -> fetch_assoc()) {
      
     $pimagess = $fieldinfo['image'];
      
 ?>
    
    
    
    <img src="<?php echo   $pimagess; ?>" width=290px height=290px/> 
	
	
	<?php 
         
          
      
       }
  $result -> free_result();
}
    ?>
    
</div>
<h1>CANADIAN DESIGNERS|DES CREATEURS CANADIENS</h1>
<div class="image-container1">

  <?php 
    
   $sql = "SELECT * FROM fetchimage Where img_typ = 5";

if ($result = $con -> query($sql)) { 
    
    
    
    
  while ($fieldinfo = $result -> fetch_assoc()) {
      
     $pimagess = $fieldinfo['image'];
      
 ?>
    
    
    
    <img src="<?php echo   $pimagess; ?>" width=530px height=450px/> 
	
	
	<?php 
         
          
      
       }
  $result -> free_result();
}
    ?>
 
	</div>
	<h3>GRETA-CONSTANTINE   LUCIAN-MATIS</h3>
    <h4>Greta Constantine is a collection of womenswear based in Toronto, Canada.Founded in 2006 by </br>designers Kirk Pickersgill and Stephen Wong.
	Exploring and challenging the fashions of today for</br>the women of tomorrow</h4>
    <h5>Lucian Matis is a Toronto-based womenswear designer whose eponymous label feature elegant</br>
	daywear and eveningwear with couture-quality embellishment.</h5>
<div class="button">
<button type="button">VIEW COLLECTION</button>
</div>
</br>
<div class="banner">
   <?php 
    
   $sql = "SELECT * FROM fetchimage Where img_typ = 6";

if ($result = $con -> query($sql)) { 
    
    
    
    
  while ($fieldinfo = $result -> fetch_assoc()) {
      
     $pimagess = $fieldinfo['image'];
      
 ?>
    
    
    
    <img src="<?php echo   $pimagess; ?>" width=100%/> 
	
	
	<?php 
         
          
      
       }
  $result -> free_result();
}
    ?>
    
</div>
</br>
</br>
</br>
<h6>
	Designer clothing and dresses for every occasion</br>
	Wheather it's a work event, a cocktail party, a bal, a wedding, your graduation or a birthday party, tell us your occasion
	and our team of stylists will guide you with the right selection
</h6>
</br>
<div class="footer">
<footer>
       <section class="left">
         <aside>QUICK-LINKS</br></br>Search</br>About</br>Contact</br>Side-Guides</br>Shipping-info</br>Return-Policies</br>
		Tres-Chic-website</br>Gift-Card|Carte-Cadeau</aside>
         <aside>BOUTIQUE</br></br>1638 Boul.de.l'avenir,</br>Laval,Qc,H752N4,Canada</br>T:450.973.6500</br></br>HOURS</br>Sunday&Monday-Closed</br>Tuesday-Friday:10am-6pm</br>Saturday:10am-5pm </aside>		 
		 <aside>INFOLETTRE|NEWSLETTER</br></br>Inscrivez-vous-a-notre-infolettre</br>Sign-up-for-our-special-friends-list.</aside>
       </section>
     </footer>
</div>
<div class="text">
 <p>A PROPOS POLITIQUE-DE-CONFIDENTIALITE TERMES-ET-CONDISTIONS CONTACTEZ-NOUS</p>
 <p>Copyright@2021.TRES-CHIC</P>
 <div class="gif">
 <img src="cc_amex.gif"/>
 <img src="cc_mc.gif"/>
 <img src="cc_pp.gif"/>
 <img src="cc_visa.gif"/>
 </div>
</body>
</html>